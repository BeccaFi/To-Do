

// :(

// function getTodosFromList(req, res, next) {

        // Jättejättejättefel
//             const listIndex = listsData.findIndex(lista => lista.ListName === list.innerText);
//             const clickedListID = listsData[listIndex].List_ID;
//             req.todoList = listsData[listIndex];
//             next();
//         }

//         exports.getTodosFromList = getTodosFromList;